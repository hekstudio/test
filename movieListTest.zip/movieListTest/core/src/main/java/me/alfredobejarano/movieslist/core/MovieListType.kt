package me.alfredobejarano.movieslist.core

/**
 * Created by alfredo on 2019-08-02.
 */
enum class MovieListType {
    MOVIE_LIST_POPULAR,
    MOVIE_LIST_UPCOMING,
    MOVIE_LIST_TOP_RATED
}