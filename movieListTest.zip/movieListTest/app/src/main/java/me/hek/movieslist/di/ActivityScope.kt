package me.alfredobejarano.movieslist.di

import javax.inject.Scope

/**
 * Created by alfredo on 2019-08-02.
 */
@Scope
@Retention(AnnotationRetention.RUNTIME)
annotation class ActivityScope